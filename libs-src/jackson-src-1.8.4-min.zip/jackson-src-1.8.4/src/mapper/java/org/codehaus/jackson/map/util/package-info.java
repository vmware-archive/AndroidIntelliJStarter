/**
 * Utility classes for Mapper package.
 */
package org.codehaus.jackson.map.util;
